# utils.py

def dictionnaire_blosum62(filepath="blosum62.txt"):
    """
    Lit la matrice BLOSUM62 a partir du fichier donne et retourne un dictionnaire.
    """
    with open(filepath, "r") as fichier_in:
        lignes_utiles = [ligne for ligne in fichier_in if not ligne.startswith("#")]

    cle_primaire = lignes_utiles[0].strip().split()
    dictionnaire = {}

    for ligne in lignes_utiles[1:]:
        valeurs = ligne.strip().split()
        cle_ligne = valeurs.pop(0)
        dictionnaire[cle_ligne] = {c: int(v) for c, v in zip(cle_primaire, valeurs)}

    return dictionnaire


def charger_proteine(filepath):
    """
    Charge une sequence proteique a partir d’un fichier texte.
    """
    sequence = ""
    with open(filepath, "r") as fichier:
        for ligne in fichier:
            sequence += ligne.strip()
    return sequence


def score(prot1_aligne, prot2_aligne, dictionnaire):
    """
    Calcule les scores de similarite et dissimilarite entre deux sequences alignees.
    """
    score_similarity = 0
    score_disimilarity = 0
    identities = 0
    similarities = 0
    length = len(prot1_aligne)

    for i in range(length):
        a = prot1_aligne[i]
        b = prot2_aligne[i]
        if a == '-' or b == '-':
            continue
        score = dictionnaire[a][b]
        if a == b:
            identities += 1
            score_similarity += score
        elif score > 0:
            similarities += 1
            score_similarity += score
        else:
            score_disimilarity += score

    return score_similarity, score_disimilarity, identities, similarities, length


def position(prot1_aligne, prot2_aligne, score_similarity, score_disimilarity, identities, similarities, length, cout_total):
    """
    Affiche les resultats de l’alignement facon EMBOSS.
    """
    total_len = length
    gap_count = prot1_aligne.count('-') + prot2_aligne.count('-')
    gap_percent = round((gap_count / (2 * total_len)) * 100, 2)
    identity_percent = round((identities / total_len) * 100, 2)
    similarity_percent = round((similarities / total_len) * 100, 2)

    print("\n=========== EMBOSS ALIGNMENT ===========")
    print("> Proteine 1 :")
    print(prot1_aligne)
    print("> Proteine 2 :")
    print(prot2_aligne)
    print("------------------------------------------")
    print(f"Identites exactes      : {identities}/{total_len} ({identity_percent}%)")
    print(f"Similarites positives  : {similarities}/{total_len} ({similarity_percent}%)")
    print(f"Score BLOSUM total     : {score_similarity}")
    print(f"Score dissimilarite    : {score_disimilarity}")
    print(f"Gaps                   : {gap_count} ({gap_percent}%)")
    print(f"Score total alignement : {cout_total}")
    print("------------------------------------------\n")
