# alignments.py

def alignement2(prot1, prot2, gap_penalty, dictionnaire):
    """
    Alignement global classique utilisant la matrice de substitution.
    """
    lg_prot1 = len(prot1)
    lg_prot2 = len(prot2)
    tableau = [[0] * (lg_prot2 + 1) for _ in range(lg_prot1 + 1)]

    for i in range(1, lg_prot1 + 1):
        tableau[i][0] = tableau[i - 1][0] + gap_penalty
    for j in range(1, lg_prot2 + 1):
        tableau[0][j] = tableau[0][j - 1] + gap_penalty

    for i in range(1, lg_prot1 + 1):
        for j in range(1, lg_prot2 + 1):
            sub = tableau[i - 1][j - 1] + dictionnaire[prot1[i - 1]][prot2[j - 1]]
            delete = tableau[i - 1][j] + gap_penalty
            insert = tableau[i][j - 1] + gap_penalty
            tableau[i][j] = max(sub, delete, insert)

    i, j = lg_prot1, lg_prot2
    prot1_aligne, prot2_aligne = '', ''
    while i > 0 or j > 0:
        if i > 0 and j > 0 and tableau[i][j] == tableau[i - 1][j - 1] + dictionnaire[prot1[i - 1]][prot2[j - 1]]:
            prot1_aligne = prot1[i - 1] + prot1_aligne
            prot2_aligne = prot2[j - 1] + prot2_aligne
            i -= 1
            j -= 1
        elif i > 0 and tableau[i][j] == tableau[i - 1][j] + gap_penalty:
            prot1_aligne = prot1[i - 1] + prot1_aligne
            prot2_aligne = '-' + prot2_aligne
            i -= 1
        else:
            prot1_aligne = '-' + prot1_aligne
            prot2_aligne = prot2[j - 1] + prot2_aligne
            j -= 1

    score_total = tableau[lg_prot1][lg_prot2]
    return prot1_aligne, prot2_aligne, score_total


def alignement_global_gap_affine(seq1, seq2, gap_open, gap_extend, dictionnaire):
    """
    Alignement global avec pénalité affine pour les gaps.
    """
    n, m = len(seq1), len(seq2)
    M = [[0] * (m + 1) for _ in range(n + 1)]
    Ix = [[float('-inf')] * (m + 1) for _ in range(n + 1)]
    Iy = [[float('-inf')] * (m + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        M[i][0] = gap_open + (i - 1) * gap_extend
    for j in range(1, m + 1):
        M[0][j] = gap_open + (j - 1) * gap_extend

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            Ix[i][j] = max(Ix[i - 1][j] + gap_extend, M[i - 1][j] + gap_open)
            Iy[i][j] = max(Iy[i][j - 1] + gap_extend, M[i][j - 1] + gap_open)
            match = M[i - 1][j - 1] + dictionnaire[seq1[i - 1]][seq2[j - 1]]
            M[i][j] = max(match, Ix[i][j], Iy[i][j])

    i, j = n, m
    align1, align2 = '', ''
    current_matrix = M

    while i > 0 or j > 0:
        if i > 0 and j > 0 and current_matrix == M and M[i][j] == M[i - 1][j - 1] + dictionnaire[seq1[i - 1]][seq2[j - 1]]:
            align1 = seq1[i - 1] + align1
            align2 = seq2[j - 1] + align2
            i -= 1
            j -= 1
        elif i > 0 and M[i][j] == Ix[i][j]:
            align1 = seq1[i - 1] + align1
            align2 = '-' + align2
            i -= 1
        elif j > 0:
            align1 = '-' + align1
            align2 = seq2[j - 1] + align2
            j -= 1

    return align1, align2, M[n][m]
