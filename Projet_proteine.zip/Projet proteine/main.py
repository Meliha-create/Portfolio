# main.py

from alignements import alignement2, alignement_global_gap_affine
from utils import charger_proteine, dictionnaire_blosum62, position, score


def main():
    # Chargement de la matrice BLOSUM62
    dictionnaire = dictionnaire_blosum62("blosum62.txt")

    # Chargement des sequences proteiques
    prot1 = charger_proteine("Prot1.txt")
    prot2 = charger_proteine("Prot2.txt")
    prot3 = charger_proteine("Prot3.txt")

    # Parametres
    gap_penalty = -8
    gap_open = -10
    gap_extend = -1

    # ALIGNEMENT CLASSIQUE : Prot1 vs Prot2
    prot1_aligne, prot2_aligne, score_total_12 = alignement2(prot1, prot2, gap_penalty, dictionnaire)
    sim12, dissim12, identities12, similarities12, length12 = score(prot1_aligne, prot2_aligne, dictionnaire)
    position(prot1_aligne, prot2_aligne, sim12, dissim12, identities12, similarities12, length12, score_total_12)

    # ALIGNEMENT CLASSIQUE : Prot1 vs Prot3
    prot1_aligne_3, prot3_aligne, score_total_13 = alignement2(prot1, prot3, gap_penalty, dictionnaire)
    sim13, dissim13, identities13, similarities13, length13 = score(prot1_aligne_3, prot3_aligne, dictionnaire)
    position(prot1_aligne_3, prot3_aligne, sim13, dissim13, identities13, similarities13, length13, score_total_13)

    # ALIGNEMENT GAP AFFINE (exemple simple)
    seq1 = "THEIERE"
    seq2 = "MARITIME"
    seq1_aligne, seq2_aligne, score_affine = alignement_global_gap_affine(seq1, seq2, gap_open, gap_extend, dictionnaire)
    print("\n--- Alignement avec gap affine ---")
    print(seq1_aligne)
    print(seq2_aligne)
    print(f"Score total (gap affine) : {score_affine}")

if __name__ == "__main__":
    main()
